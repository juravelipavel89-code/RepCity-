import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'services/cloud_sync.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  const url = String.fromEnvironment('SUPABASE_URL');
  const key = String.fromEnvironment('SUPABASE_PUBLISHABLE_KEY');
  if (url.isNotEmpty && key.isNotEmpty) {
    await Supabase.initialize(url: url, anonKey: key);
  }
  runApp(const RepCityApp());
}

const lime = Color(0xFFB7F34A);
const bg = Color(0xFF101310);
const panel = Color(0xFF1B201B);

class ExerciseEntry {
  final String id, name;
  final int reps;
  final DateTime date;
  ExerciseEntry({required this.id, required this.name, required this.reps, required this.date});
  Map<String,dynamic> toJson() => {'id':id,'name':name,'reps':reps,'date':date.toIso8601String()};
  factory ExerciseEntry.fromJson(Map<String,dynamic> j) => ExerciseEntry(
    id:j['id'], name:j['name'], reps:j['reps'], date:DateTime.parse(j['date']));
}

class RepCityApp extends StatefulWidget {
  const RepCityApp({super.key});
  @override State<RepCityApp> createState()=>_RepCityAppState();
}

class _RepCityAppState extends State<RepCityApp> {
  int tab=0;
  bool loading=true;
  bool syncing=false;
  String? cloudMessage;
  bool get cloudConfigured => const String.fromEnvironment('SUPABASE_URL').isNotEmpty && const String.fromEnvironment('SUPABASE_PUBLISHABLE_KEY').isNotEmpty;
  bool get signedIn => cloudConfigured && RepCityCloudSync.instance.isSignedIn;
  String? get signedInEmail => cloudConfigured ? RepCityCloudSync.instance.currentUser?.email : null;
  DateTime selectedDate=DateUtils.dateOnly(DateTime.now());
  List<ExerciseEntry> entries=[];
  final exercises=['Push-ups','Squats','Pull-ups','Sit-ups','Lunges','Burpees','Plank (seconds)'];

  @override void initState(){super.initState();_load();}
  Future<void> _load() async {
    final p=await SharedPreferences.getInstance();
    final raw=p.getString('repcity_entries_v1');
    if(raw!=null){try{entries=(jsonDecode(raw) as List).map((x)=>ExerciseEntry.fromJson(x)).toList();}catch(_){entries=[];}}
    if(mounted)setState(()=>loading=false);
    if (cloudConfigured && RepCityCloudSync.instance.isSignedIn) {
      await _syncFromCloud(showMessage: false);
    }
  }
  Future<void> _save() async {
    final p=await SharedPreferences.getInstance();
    await p.setString('repcity_entries_v1',jsonEncode(entries.map((e)=>e.toJson()).toList()));
  }
  int points(ExerciseEntry e){
    if(e.name=='Squats'||e.name=='Lunges')return e.reps~/2;
    if(e.name=='Pull-ups'||e.name=='Burpees')return e.reps*3;
    if(e.name=='Plank (seconds)')return e.reps~/10;
    return e.reps;
  }
  int get xp=>entries.fold(0,(s,e)=>s+points(e));
  int get level=>1+xp~/500;
  int get totalReps=>entries.fold(0,(s,e)=>s+e.reps);
  int totalFor(String name)=>entries.where((e)=>e.name==name).fold(0,(s,e)=>s+e.reps);
  int xpForDay(DateTime d)=>entries.where((e)=>DateUtils.isSameDay(e.date,d)).fold(0,(s,e)=>s+points(e));
  List<ExerciseEntry> entriesFor(DateTime d)=>entries.where((e)=>DateUtils.isSameDay(e.date,d)).toList()..sort((a,b)=>a.date.compareTo(b.date));
  int get activeDays=>entries.map((e)=>DateUtils.dateOnly(e.date)).toSet().length;
  int get workoutCount=>entries.length;

  Future<void> addEntry(String name,int reps,DateTime date) async {
    setState(()=>entries.add(ExerciseEntry(id:'${DateTime.now().microsecondsSinceEpoch}',name:name,reps:reps,date:date)));
    await _save();
    await _uploadEntry(entries.last);
  }
  Future<void> deleteEntry(ExerciseEntry e) async {
    setState(()=>entries.removeWhere((x)=>x.id==e.id)); await _save();
    if (signedIn) {
      try { await RepCityCloudSync.instance.deleteEntry(e.id); } catch (err) { _setCloudMessage('Delete sync failed: $err'); }
    }
  }
  Future<void> editEntry(ExerciseEntry e,int value) async {
    final i=entries.indexWhere((x)=>x.id==e.id);
    if(i>=0){setState(()=>entries[i]=ExerciseEntry(id:e.id,name:e.name,reps:value,date:e.date));await _save();await _uploadEntry(entries[i]);}
  }

  void _setCloudMessage(String message) {
    if (mounted) setState(() => cloudMessage = message);
  }

  Future<void> _uploadEntry(ExerciseEntry entry) async {
    if (!signedIn) return;
    try {
      await RepCityCloudSync.instance.uploadEntries([entry.toJson()]);
      _setCloudMessage('Cloud sync complete');
    } catch (err) {
      _setCloudMessage('Cloud sync error: $err');
    }
  }

  Future<void> _syncFromCloud({bool showMessage = true}) async {
    if (!signedIn || syncing) return;
    setState(() => syncing = true);
    try {
      final remote = await RepCityCloudSync.instance.downloadEntries();
      final byId = {for (final e in entries) e.id: e};
      for (final row in remote) {
        final entry = ExerciseEntry.fromJson(row);
        byId[entry.id] = entry;
      }
      setState(() {
        entries = byId.values.toList()..sort((a,b)=>a.date.compareTo(b.date));
      });
      await _save();
      // Upload local-only records after merge (safe upsert by user_id + id).
      final remoteIds = remote.map((e) => e['id'].toString()).toSet();
      final localOnly = entries.where((e) => !remoteIds.contains(e.id)).map((e) => e.toJson()).toList();
      if (localOnly.isNotEmpty) await RepCityCloudSync.instance.uploadEntries(localOnly);
      if (showMessage) _setCloudMessage('Synced ${entries.length} workout records');
    } catch (err) {
      _setCloudMessage('Sync failed: $err');
    } finally {
      if (mounted) setState(() => syncing = false);
    }
  }

  Future<void> _showAuthDialog({required bool register}) async {
    if (!cloudConfigured) {
      _setCloudMessage('Cloud is not configured. Add Supabase URL and publishable key to run arguments.');
      return;
    }
    final email = TextEditingController();
    final password = TextEditingController();
    final username = TextEditingController();
    String? errorText;
    await showDialog(context: context, builder: (ctx) => StatefulBuilder(builder: (ctx, setDialogState) => AlertDialog(
      title: Text(register ? 'Create RepCity account' : 'Sign in to RepCity'),
      content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
        if (register) TextField(controller: username, decoration: const InputDecoration(labelText: 'Username')),
        TextField(controller: email, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'Email')),
        TextField(controller: password, obscureText: true, decoration: const InputDecoration(labelText: 'Password')),
        if (errorText != null) Padding(padding: const EdgeInsets.only(top: 10), child: Text(errorText!, style: const TextStyle(color: Colors.redAccent))),
      ])),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('CANCEL')),
        FilledButton(onPressed: () async {
          try {
            if (register) {
              if (username.text.trim().length < 3) throw Exception('Username must contain at least 3 characters.');
              await RepCityCloudSync.instance.signUp(email: email.text, password: password.text, username: username.text);
            } else {
              await RepCityCloudSync.instance.signIn(email: email.text, password: password.text);
            }
            if (ctx.mounted) Navigator.pop(ctx);
            await _syncFromCloud();
            _setCloudMessage(register ? 'Account created. Check your email if confirmation is required.' : 'Signed in and synced.');
          } catch (err) {
            setDialogState(() => errorText = err.toString());
          }
        }, child: Text(register ? 'REGISTER' : 'SIGN IN')),
      ],
    )));
  }

  Future<void> _signOut() async {
    try {
      await RepCityCloudSync.instance.signOut();
      _setCloudMessage('Signed out. Local workout history remains on this device.');
    } catch (err) { _setCloudMessage('Sign out failed: $err'); }
  }

  @override Widget build(BuildContext context){
    final pages=[homePage(),workoutPage(),calendarPage(),leaderboardPage(),profilePage()];
    return MaterialApp(debugShowCheckedModeBanner:false,theme:ThemeData.dark().copyWith(
      scaffoldBackgroundColor:bg,colorScheme:const ColorScheme.dark(primary:lime,surface:panel),
      appBarTheme:const AppBarTheme(backgroundColor:bg,foregroundColor:Colors.white),
    ),home:Scaffold(
      appBar:AppBar(title:const Text('REPCITY',style:TextStyle(letterSpacing:3,fontWeight:FontWeight.w900)),actions:[IconButton(onPressed:()=>showAboutDialog(context:context,applicationName:'RepCity',applicationVersion:'0.4.0',children:[const Text('Lifetime exercise tracker prototype. Data is stored locally on this device.')]),icon:const Icon(Icons.info_outline))]),
      body:loading?const Center(child:CircularProgressIndicator(color:lime)):pages[tab],
      bottomNavigationBar:NavigationBar(backgroundColor:panel,indicatorColor:lime.withOpacity(.18),selectedIndex:tab,onDestinationSelected:(v)=>setState(()=>tab=v),destinations:const[
        NavigationDestination(icon:Icon(Icons.home_outlined),label:'Home'),
        NavigationDestination(icon:Icon(Icons.add_circle_outline),label:'Workout'),
        NavigationDestination(icon:Icon(Icons.calendar_month_outlined),label:'Calendar'),
        NavigationDestination(icon:Icon(Icons.leaderboard_outlined),label:'Ranks'),
        NavigationDestination(icon:Icon(Icons.person_outline),label:'Profile'),
      ]),
    ));
  }
  Widget shell(List<Widget> c)=>ListView(padding:const EdgeInsets.all(18),children:c);
  Widget card(Widget c)=>Container(margin:const EdgeInsets.only(bottom:13),padding:const EdgeInsets.all(15),decoration:BoxDecoration(color:panel,borderRadius:BorderRadius.circular(17),border:Border.all(color:Colors.white10)),child:c);
  Widget label(String s)=>Text(s.toUpperCase(),style:const TextStyle(color:Colors.white60,fontSize:11,letterSpacing:1.5,fontWeight:FontWeight.bold));
  Widget stat(String title,int value,IconData icon)=>Container(padding:const EdgeInsets.all(14),decoration:BoxDecoration(color:panel,borderRadius:BorderRadius.circular(15)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[Icon(icon,color:lime,size:18),Text(value.toString(),style:const TextStyle(fontSize:23,fontWeight:FontWeight.w900)),Text(title.toUpperCase(),style:const TextStyle(color:Colors.white54,fontSize:10,letterSpacing:1))]));

  Widget homePage()=>shell([
    Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[label('ATHLETE PROFILE'),Chip(label:Text('LEVEL $level'),backgroundColor:lime,labelStyle:const TextStyle(color:Colors.black,fontWeight:FontWeight.bold))]),
    card(Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('YOUR REPS. YOUR HISTORY.',style:TextStyle(color:lime,letterSpacing:1.2,fontWeight:FontWeight.bold)),const SizedBox(height:10),Text('$xp XP',style:const TextStyle(fontSize:38,fontWeight:FontWeight.w900)),const SizedBox(height:8),LinearProgressIndicator(value:(xp%500)/500,minHeight:8,backgroundColor:Colors.white12,color:lime),const SizedBox(height:7),Text('${xp%500} / 500 XP TO NEXT LEVEL',style:const TextStyle(color:Colors.white54,fontSize:10))])),
    label('LIFETIME TOTALS'),GridView.count(shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),crossAxisCount:2,childAspectRatio:1.65,crossAxisSpacing:10,mainAxisSpacing:10,children:[
      stat('Push-ups',totalFor('Push-ups'),Icons.fitness_center),stat('Squats',totalFor('Squats'),Icons.directions_run),stat('Pull-ups',totalFor('Pull-ups'),Icons.sports_gymnastics),stat('All reps',totalReps,Icons.bolt)]),
    const SizedBox(height:18),label('TODAY'),card(Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[const Text('Activity points'),Text('${xpForDay(DateTime.now())} XP',style:const TextStyle(color:lime,fontWeight:FontWeight.bold,fontSize:20))])),
    label('RECENT ACTIVITY'),...entries.reversed.take(5).map((e)=>card(ListTile(contentPadding:EdgeInsets.zero,leading:const Icon(Icons.check_circle,color:lime),title:Text(e.name),subtitle:Text('${e.date.day}.${e.date.month}.${e.date.year}'),trailing:Text('+${e.reps}',style:const TextStyle(fontWeight:FontWeight.bold)))))
  ]);

  Widget workoutPage()=>shell([
    label('MANUAL WORKOUT LOG'),const SizedBox(height:8),const Text('Every rep counts.',style:TextStyle(fontSize:28,fontWeight:FontWeight.w900)),const SizedBox(height:6),const Text('Choose an exercise, enter your reps and select the workout date.',style:TextStyle(color:Colors.white60)),
    const SizedBox(height:16),card(ListTile(contentPadding:EdgeInsets.zero,title:const Text('Workout date'),subtitle:Text('${selectedDate.day}.${selectedDate.month}.${selectedDate.year}'),trailing:const Icon(Icons.calendar_month,color:lime),onTap:()async{final d=await showDatePicker(context:context,initialDate:selectedDate,firstDate:DateTime(2000),lastDate:DateTime.now());if(d!=null)setState(()=>selectedDate=d);})),
    ...exercises.map((n)=>card(ListTile(contentPadding:EdgeInsets.zero,title:Text(n,style:const TextStyle(fontWeight:FontWeight.bold)),subtitle:Text('Lifetime: ${totalFor(n)}'),trailing:const Icon(Icons.add_circle,color:lime),onTap:()=>showAddDialog(n)))),
  ]);

  Future<void> showAddDialog(String name,{ExerciseEntry? existing}) async {
    final c=TextEditingController(text:existing?.reps.toString()??'');
    await showDialog(context:context,builder:(ctx)=>AlertDialog(title:Text(existing==null?'Add $name':'Edit $name'),content:TextField(controller:c,keyboardType:TextInputType.number,autofocus:true,decoration:const InputDecoration(labelText:'Reps / seconds')),actions:[
      TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('CANCEL')),
      FilledButton(onPressed:()async{final n=int.tryParse(c.text);if(n!=null&&n>0){if(existing==null){await addEntry(name,n,selectedDate);}else{await editEntry(existing,n);}}if(ctx.mounted)Navigator.pop(ctx);},child:const Text('SAVE'))]));
  }

  Widget calendarPage(){
    final now=DateTime.now();final first=DateTime(selectedDate.year,selectedDate.month,1);final days=DateTime(selectedDate.year,selectedDate.month+1,0).day;final offset=(first.weekday-1);
    final dayEntries=entriesFor(selectedDate);
    return shell([label('TRAINING HISTORY'),Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[IconButton(onPressed:()=>setState(()=>selectedDate=DateTime(selectedDate.year,selectedDate.month-1,1)),icon:const Icon(Icons.chevron_left)),Text('${_month(selectedDate.month)} ${selectedDate.year}',style:const TextStyle(fontSize:23,fontWeight:FontWeight.w900)),IconButton(onPressed:()=>setState(()=>selectedDate=DateTime(selectedDate.year,selectedDate.month+1,1)),icon:const Icon(Icons.chevron_right))]),
      card(Column(children:[const Row(mainAxisAlignment:MainAxisAlignment.spaceAround,children:['M','T','W','T','F','S','S'].map((x)=>Text(x,style:TextStyle(color:Colors.white54))).toList()),const SizedBox(height:10),GridView.count(shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),crossAxisCount:7,childAspectRatio:1.1,children:[...List.generate(offset,(_)=>const SizedBox()),...List.generate(days,(i){final d=DateTime(selectedDate.year,selectedDate.month,i+1);final active=entries.any((e)=>DateUtils.isSameDay(e.date,d));final chosen=DateUtils.isSameDay(d,selectedDate);return InkWell(onTap:()=>setState(()=>selectedDate=d),child:Container(margin:const EdgeInsets.all(3),decoration:BoxDecoration(color:chosen?lime:active?lime.withOpacity(.18):Colors.transparent,borderRadius:BorderRadius.circular(9),border:active&&!chosen?Border.all(color:lime.withOpacity(.5)):null),alignment:Alignment.center,child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[Text('${i+1}',style:TextStyle(color:chosen?Colors.black:Colors.white,fontWeight:FontWeight.bold)),if(active)Container(width:4,height:4,decoration:BoxDecoration(color:chosen?Colors.black:lime,shape:BoxShape.circle))])));})]) ])),
      label('SELECTED DAY · ${selectedDate.day}.${selectedDate.month}.${selectedDate.year}'),
      if(dayEntries.isEmpty)card(const Text('No exercises logged on this day.',style:TextStyle(color:Colors.white54))) else ...dayEntries.map((e)=>card(ListTile(contentPadding:EdgeInsets.zero,title:Text(e.name),subtitle:Text('${points(e)} XP earned'),trailing:Row(mainAxisSize:MainAxisSize.min,children:[Text('${e.reps}  '),PopupMenuButton<String>(onSelected:(v){if(v=='edit')showAddDialog(e.name,existing:e);if(v=='delete')deleteEntry(e);},itemBuilder:(_)=>const[PopupMenuItem(value:'edit',child:Text('Edit')),PopupMenuItem(value:'delete',child:Text('Delete'))])])))),
      card(Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[const Text('Day total'),Text('${xpForDay(selectedDate)} XP',style:const TextStyle(color:lime,fontWeight:FontWeight.bold))]))
    ]);
  }
  String _month(int m)=>['','January','February','March','April','May','June','July','August','September','October','November','December'][m];

  Widget leaderboardPage()=>shell([label('COMPETE WITH THE CITY'),const Text('Leaderboard',style:TextStyle(fontSize:30,fontWeight:FontWeight.w900)),card(Column(children:[rank(1,'AlexFit','18,420 XP'),rank(2,'RepMachine','15,890 XP'),rank(3,'YOU','$xp XP',you:true),rank(4,'IronMila','6,720 XP'),rank(5,'RunnerX','5,980 XP')])),label('CHALLENGES'),
    card(ListTile(leading:const Icon(Icons.local_fire_department,color:lime),title:const Text('7-Day Consistency'),subtitle:Text('$activeDays / 7 active days'),trailing:const Icon(Icons.flag_outlined))),
    card(ListTile(leading:const Icon(Icons.bolt,color:lime),title:const Text('Century Club'),subtitle:Text('$totalReps / 100 total reps'),trailing:const Icon(Icons.emoji_events_outlined))),
    card(ListTile(leading:const Icon(Icons.fitness_center,color:lime),title:const Text('First 1,000 Reps'),subtitle:Text('$totalReps / 1,000 total reps'),trailing:const Icon(Icons.military_tech))),
    const Text('Leaderboard entries are demo data. Real global and friends rankings require accounts and a shared backend.',style:TextStyle(color:Colors.white38,fontSize:11))
  ]);
  Widget rank(int n,String name,String score,{bool you=false})=>ListTile(leading:CircleAvatar(backgroundColor:you?lime:Colors.white10,child:Text('$n',style:TextStyle(color:you?Colors.black:Colors.white))),title:Text(name,style:TextStyle(fontWeight:you?FontWeight.bold:FontWeight.normal)),trailing:Text(score,style:TextStyle(color:you?lime:Colors.white70)));

  Widget profilePage()=>shell([
    label('ACCOUNT & CLOUD'),
    card(Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Row(children:[Icon(signedIn?Icons.cloud_done:Icons.cloud_off,color:signedIn?lime:Colors.white54),const SizedBox(width:10),Expanded(child:Text(signedIn?'Connected to RepCity Cloud':cloudConfigured?'Not signed in':'Cloud not configured',style:const TextStyle(fontWeight:FontWeight.bold))),if(syncing)const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2,color:lime))]),
      if (signedInEmail != null) Padding(padding:const EdgeInsets.only(top:6),child:Text(signedInEmail!,style:const TextStyle(color:Colors.white60))),
      if (cloudMessage != null) Padding(padding:const EdgeInsets.only(top:8),child:Text(cloudMessage!,style:const TextStyle(color:Colors.white54,fontSize:12))),
      const SizedBox(height:12),
      if (!cloudConfigured) const Text('Launch with SUPABASE_URL and SUPABASE_PUBLISHABLE_KEY to enable cloud accounts.',style:TextStyle(color:Colors.white54,fontSize:12)),
      if (cloudConfigured && !signedIn) Wrap(spacing:8,runSpacing:8,children:[
        FilledButton(onPressed:()=>_showAuthDialog(register:true),child:const Text('CREATE ACCOUNT')),
        OutlinedButton(onPressed:()=>_showAuthDialog(register:false),child:const Text('SIGN IN')),
      ]),
      if (signedIn) Wrap(spacing:8,runSpacing:8,children:[
        FilledButton(onPressed:syncing?null:()=>_syncFromCloud(),child:const Text('SYNC NOW')),
        OutlinedButton(onPressed:_signOut,child:const Text('SIGN OUT')),
      ]),
    ])),
    label('YOUR ATHLETE CARD'),card(Column(children:[const CircleAvatar(radius:36,backgroundColor:lime,child:Icon(Icons.person,color:Colors.black,size:38)),const SizedBox(height:12),const Text('REP CITY ATHLETE',style:TextStyle(fontSize:20,fontWeight:FontWeight.w900)),Text('LEVEL $level',style:const TextStyle(color:lime,fontWeight:FontWeight.bold)),Text('$xp lifetime XP · $activeDays active days',style:const TextStyle(color:Colors.white60))])),
    label('LIFETIME EXERCISE RECORDS'),...exercises.map((n)=>card(Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[Text(n),Text('${totalFor(n)}',style:const TextStyle(color:lime,fontWeight:FontWeight.bold))]))),
    label('ACHIEVEMENTS'),...[
      ['First Steps','Log your first exercise',workoutCount>=1,Icons.flag],
      ['Century Club','Reach 100 total reps',totalReps>=100,Icons.military_tech],
      ['1K Club','Reach 1,000 total reps',totalReps>=1000,Icons.emoji_events],
      ['Consistent','Train on 7 different days',activeDays>=7,Icons.local_fire_department],
      ['Dedicated','Log 50 exercise entries',workoutCount>=50,Icons.bolt],
    ].map((a)=>card(ListTile(leading:Icon(a[3] as IconData,color:(a[2] as bool)?lime:Colors.white24),title:Text(a[0] as String),subtitle:Text(a[1] as String),trailing:Icon((a[2] as bool)?Icons.check_circle:Icons.lock_outline,color:(a[2] as bool)?lime:Colors.white24)))),
    card(Column(crossAxisAlignment:CrossAxisAlignment.start,children:[label('TOTAL LIFETIME REPS'),Text(totalReps.toString(),style:const TextStyle(fontSize:30,fontWeight:FontWeight.w900)),Text('$xp XP · LEVEL $level',style:const TextStyle(color:lime))]))
  ]);
}