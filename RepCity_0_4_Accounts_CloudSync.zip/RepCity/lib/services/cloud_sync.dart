import 'package:supabase_flutter/supabase_flutter.dart';

/// Supabase bridge for RepCity. Initialize Supabase in main() before using it.
/// The anon/publishable key is safe for a client app when RLS is enabled.
/// NEVER place the service_role key in a mobile application.
class RepCityCloudSync {
  RepCityCloudSync._();
  static final RepCityCloudSync instance = RepCityCloudSync._();
  SupabaseClient get _db => Supabase.instance.client;

  User? get currentUser => _db.auth.currentUser;
  Stream<AuthState> get authChanges => _db.auth.onAuthStateChange;
  bool get isSignedIn => currentUser != null;

  Future<void> signUp({required String email, required String password, required String username}) async {
    await _db.auth.signUp(
      email: email.trim(),
      password: password,
      data: {'username': username.trim()},
    );
  }

  Future<void> signIn({required String email, required String password}) async {
    await _db.auth.signInWithPassword(email: email.trim(), password: password);
  }

  Future<void> signOut() => _db.auth.signOut();

  /// Upload local ledger records. IDs are stable per record, so retries are idempotent.
  /// Expected map keys: id, name, reps, date (ISO-8601 string).
  Future<void> uploadEntries(List<Map<String, dynamic>> localEntries) async {
    final user = currentUser;
    if (user == null) throw StateError('Sign in before syncing.');
    if (localEntries.isEmpty) return;
    final rows = localEntries.map((entry) => <String, dynamic>{
      'id': entry['id'].toString(),
      'user_id': user.id,
      'exercise_name': entry['name'],
      'reps': entry['reps'],
      'performed_at': DateTime.parse(entry['date'].toString()).toUtc().toIso8601String(),
      'updated_at': DateTime.now().toUtc().toIso8601String(),
    }).toList();
    await _db.from('exercise_entries').upsert(rows, onConflict: 'user_id,id');
  }


  Future<void> deleteEntry(String entryId) async {
    final user = currentUser;
    if (user == null) throw StateError('Sign in before syncing.');
    await _db.from('exercise_entries').delete()
        .eq('user_id', user.id).eq('id', entryId);
  }

  /// Fetch cloud ledger in chronological order. Caller can merge by record id.
  Future<List<Map<String, dynamic>>> downloadEntries() async {
    final user = currentUser;
    if (user == null) throw StateError('Sign in before syncing.');
    final rows = await _db.from('exercise_entries')
        .select('id, exercise_name, reps, performed_at')
        .eq('user_id', user.id)
        .order('performed_at');
    return (rows as List).map((row) => <String, dynamic>{
      'id': row['id'].toString(),
      'name': row['exercise_name'],
      'reps': row['reps'],
      'date': DateTime.parse(row['performed_at'].toString()).toLocal().toIso8601String(),
    }).toList();
  }

  /// Returns the global XP ranking. XP is derived in the database, not trusted from app input.
  Future<List<Map<String, dynamic>>> globalLeaderboard({int limit = 100}) async {
    final rows = await _db.from('global_leaderboard')
        .select('user_id, username, display_name, xp, total_reps, active_days')
        .order('xp', ascending: false)
        .limit(limit.clamp(1, 500));
    return (rows as List).cast<Map<String, dynamic>>();
  }

  Future<List<Map<String, dynamic>>> searchProfiles(String usernamePrefix) async {
    final query = usernamePrefix.trim();
    if (query.length < 3) return [];
    final rows = await _db.from('profiles')
        .select('id, username, display_name')
        .ilike('username', '$query%')
        .limit(20);
    return (rows as List).cast<Map<String, dynamic>>();
  }

  Future<void> sendFriendRequest(String receiverUserId) async {
    final user = currentUser;
    if (user == null) throw StateError('Sign in before adding friends.');
    await _db.from('friend_requests').insert({
      'sender_id': user.id,
      'receiver_id': receiverUserId,
      'status': 'pending',
    });
  }

  Future<void> acceptFriendRequest(String requestId) async {
    await _db.rpc('accept_friend_request', params: {'request_id': requestId});
  }

  Future<void> declineFriendRequest(String requestId) async {
    await _db.rpc('decline_friend_request', params: {'request_id': requestId});
  }

  Future<List<Map<String, dynamic>>> myFriendRequests() async {
    final user = currentUser;
    if (user == null) throw StateError('Sign in before viewing requests.');
    final rows = await _db.from('friend_requests')
        .select('id, sender_id, receiver_id, status, created_at')
        .or('sender_id.eq.${user.id},receiver_id.eq.${user.id}')
        .order('created_at', ascending: false);
    return (rows as List).cast<Map<String, dynamic>>();
  }
}
