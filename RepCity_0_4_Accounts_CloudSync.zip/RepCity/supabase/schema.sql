-- RepCity 0.3 — Supabase schema
-- Run this whole file in Supabase Dashboard -> SQL Editor.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text not null unique check (char_length(username) between 3 and 24),
  display_name text not null default 'Athlete' check (char_length(display_name) between 1 and 40),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.exercise_entries (
  id text not null,
  user_id uuid not null references auth.users(id) on delete cascade,
  exercise_name text not null check (exercise_name in ('Push-ups','Squats','Pull-ups','Sit-ups','Lunges','Burpees','Plank (seconds)')),
  reps integer not null check (reps > 0 and reps <= 1000000),
  performed_at timestamptz not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  primary key (user_id, id)
);
create index if not exists exercise_entries_user_date_idx on public.exercise_entries(user_id, performed_at desc);

create table if not exists public.friend_requests (
  id uuid primary key default gen_random_uuid(),
  sender_id uuid not null references auth.users(id) on delete cascade,
  receiver_id uuid not null references auth.users(id) on delete cascade,
  status text not null default 'pending' check (status in ('pending','accepted','declined')),
  created_at timestamptz not null default now(),
  responded_at timestamptz,
  constraint no_self_friend_request check (sender_id <> receiver_id),
  constraint unique_friend_request_pair unique (sender_id, receiver_id)
);

create table if not exists public.friendships (
  user_low uuid not null references auth.users(id) on delete cascade,
  user_high uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_low, user_high),
  check (user_low < user_high)
);

create table if not exists public.challenges (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text not null default '',
  metric text not null check (metric in ('total_reps','active_days','exercise_reps')),
  exercise_name text,
  target integer not null check (target > 0),
  starts_at timestamptz not null,
  ends_at timestamptz not null,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  check (ends_at > starts_at)
);

create table if not exists public.challenge_participants (
  challenge_id uuid not null references public.challenges(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  joined_at timestamptz not null default now(),
  primary key (challenge_id, user_id)
);

-- Create a public profile row after successful sign-up. Username can be edited later.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  raw_name text;
  safe_name text;
begin
  raw_name := coalesce(new.raw_user_meta_data ->> 'username', split_part(new.email, '@', 1), 'athlete');
  safe_name := lower(regexp_replace(raw_name, '[^a-zA-Z0-9_]', '', 'g'));
  if char_length(safe_name) < 3 then safe_name := 'athlete_' || substr(new.id::text, 1, 8); end if;
  insert into public.profiles(id, username, display_name)
  values (new.id, safe_name || '_' || substr(new.id::text, 1, 4), coalesce(nullif(raw_name,''), 'Athlete'))
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created_repcity on auth.users;
create trigger on_auth_user_created_repcity
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- XP is calculated on the server from exercise records; clients cannot submit XP.
create or replace view public.global_leaderboard as
select p.id as user_id, p.username, p.display_name,
       coalesce(sum(case
         when e.exercise_name in ('Squats','Lunges') then e.reps / 2
         when e.exercise_name in ('Pull-ups','Burpees') then e.reps * 3
         when e.exercise_name = 'Plank (seconds)' then e.reps / 10
         else e.reps end), 0)::bigint as xp,
       coalesce(sum(case when e.exercise_name <> 'Plank (seconds)' then e.reps else 0 end),0)::bigint as total_reps,
       count(distinct (e.performed_at at time zone 'UTC')::date)::bigint as active_days
from public.profiles p
left join public.exercise_entries e on e.user_id = p.id
group by p.id, p.username, p.display_name;

alter table public.profiles enable row level security;
alter table public.exercise_entries enable row level security;
alter table public.friend_requests enable row level security;
alter table public.friendships enable row level security;
alter table public.challenges enable row level security;
alter table public.challenge_participants enable row level security;

-- Profiles are discoverable for friend search and public leaderboard display.
drop policy if exists "Profiles are readable" on public.profiles;
create policy "Profiles are readable" on public.profiles for select to authenticated using (true);
drop policy if exists "Users update own profile" on public.profiles;
create policy "Users update own profile" on public.profiles for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);

-- A user can only read/write their own exercise log.
drop policy if exists "Read own entries" on public.exercise_entries;
create policy "Read own entries" on public.exercise_entries for select to authenticated using (auth.uid() = user_id);
drop policy if exists "Insert own entries" on public.exercise_entries;
create policy "Insert own entries" on public.exercise_entries for insert to authenticated with check (auth.uid() = user_id);
drop policy if exists "Update own entries" on public.exercise_entries;
create policy "Update own entries" on public.exercise_entries for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
drop policy if exists "Delete own entries" on public.exercise_entries;
create policy "Delete own entries" on public.exercise_entries for delete to authenticated using (auth.uid() = user_id);

-- Users see requests they sent or received; only the receiver can respond.
drop policy if exists "Read involved requests" on public.friend_requests;
create policy "Read involved requests" on public.friend_requests for select to authenticated using (auth.uid() = sender_id or auth.uid() = receiver_id);
drop policy if exists "Send friend requests" on public.friend_requests;
create policy "Send friend requests" on public.friend_requests for insert to authenticated with check (auth.uid() = sender_id and status = 'pending');
-- Responses are performed only through the RPC functions below.

-- Friendship rows are readable only by either member; creation is via the RPC below.
drop policy if exists "Read own friendships" on public.friendships;
create policy "Read own friendships" on public.friendships for select to authenticated using (auth.uid() = user_low or auth.uid() = user_high);

create or replace function public.accept_friend_request(request_id uuid)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare r public.friend_requests%rowtype;
begin
  select * into r from public.friend_requests where id = request_id for update;
  if not found or r.receiver_id <> auth.uid() or r.status <> 'pending' then
    raise exception 'Friend request not found or not available';
  end if;
  update public.friend_requests set status='accepted', responded_at=now() where id=request_id;
  insert into public.friendships(user_low,user_high)
  values (least(r.sender_id,r.receiver_id), greatest(r.sender_id,r.receiver_id))
  on conflict do nothing;
end;
$$;
grant execute on function public.accept_friend_request(uuid) to authenticated;

create or replace function public.decline_friend_request(request_id uuid)
returns void
language plpgsql
security definer
set search_path = ''
as $$
begin
  update public.friend_requests
     set status='declined', responded_at=now()
   where id=request_id and receiver_id=auth.uid() and status='pending';
  if not found then raise exception 'Friend request not found or not available'; end if;
end;
$$;
grant execute on function public.decline_friend_request(uuid) to authenticated;

-- Active challenge catalogue is readable; participants manage only their own membership.
drop policy if exists "Read active challenges" on public.challenges;
create policy "Read active challenges" on public.challenges for select to authenticated using (is_active = true);
drop policy if exists "Read challenge participants" on public.challenge_participants;
create policy "Read challenge participants" on public.challenge_participants for select to authenticated using (true);
drop policy if exists "Join challenge" on public.challenge_participants;
create policy "Join challenge" on public.challenge_participants for insert to authenticated with check (auth.uid() = user_id);
drop policy if exists "Leave challenge" on public.challenge_participants;
create policy "Leave challenge" on public.challenge_participants for delete to authenticated using (auth.uid() = user_id);

grant select on public.global_leaderboard to authenticated;

-- Optional starter challenge examples. Adjust dates before running if desired.
-- insert into public.challenges(title,description,metric,target,starts_at,ends_at)
-- values ('Century Club','Reach 100 total reps','total_reps',100,now(),now()+interval '7 days');
